export default {
  categorys:function(state,getters){
    return state.categorys
  },
  category(state){
    return state.category
  },
  isCreate(state){
    return state.isCreate
  }
}
