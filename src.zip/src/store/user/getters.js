export default {
  users:function(state,getters){
    return state.users
  },
  user(state){
    return state.user
  },
  isCreate(state){
    return state.isCreate
  }
}
