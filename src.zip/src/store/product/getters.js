export default {
  products:function(state,getters){
    return state.products
  },
  product(state){
    return state.product
  },
  isCreate(state){
    return state.isCreate
  }
}
